ptr example 2

T d[10]
type of d is T*

char** is an address

cout a char* is a string, everything else is an address

square brackets take precedence

char* x;
cin >> x;

seg fault (no array to point into)

### Images
I,j row i column j

Draw 2 pictures



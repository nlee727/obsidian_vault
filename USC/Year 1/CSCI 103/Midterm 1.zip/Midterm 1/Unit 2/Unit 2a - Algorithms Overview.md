### Algorithms:
Precise way to solve a problem
1) ordered set of unambiguous executable steps that defines a terminal step
##### Representation:
Cant be represented in one way
1) Flow Chart
2) Pseudocode, Specific Implementation


### Complexity of Search Algorithms:

### Importance of Time Complexity:

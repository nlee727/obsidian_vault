C++ is an Imperative/Structured Language

**Fact 1**: Everything in a computer is a *number*
**Fact 2**: Computer operations can only work or "see" 1 or 2 numbers at a time. (they can only do 1 thing at a time)

breadth-first search for maze
